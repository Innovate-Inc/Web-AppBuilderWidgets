﻿define(
   ({
    instruction: "Crie o conteúdo que será exibido neste widget.",
    defaultContent: "Adicione texto, ligações e pequenos gráficos aqui."
  })
);