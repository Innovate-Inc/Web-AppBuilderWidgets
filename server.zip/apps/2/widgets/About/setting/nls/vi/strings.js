﻿define(
   ({
    instruction: "Tạo nội dung hiển thị trong tiện ích này.",
    defaultContent: "Thêm văn bản, liên kết và đồ họa nhỏ ở đây."
  })
);