﻿define(
   ({
    instruction: "צור תוכן שיוצג בוידג'ט זה.",
    defaultContent: "הוסף טקסט, קישורים וגרפיקות קטנות כאן."
  })
);