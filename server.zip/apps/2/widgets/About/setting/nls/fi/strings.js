﻿define(
   ({
    instruction: "Luo sisältö, joka näkyy tässä pienoisohjelmassa.",
    defaultContent: "Lisää tähän tekstiä, linkkejä ja pieniä kuvia."
  })
);