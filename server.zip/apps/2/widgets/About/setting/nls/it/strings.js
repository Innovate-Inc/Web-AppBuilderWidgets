﻿define(
   ({
    instruction: "Creare il contenuto da visualizzare in questo widget.",
    defaultContent: "Aggiungere qui testo, collegamenti e piccole immagini."
  })
);