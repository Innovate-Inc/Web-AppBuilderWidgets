﻿define(
   ({
    instruction: "Maak de content die wordt weergegeven in deze widget.",
    defaultContent: "Voeg hier tekst, koppelingen en kleine afbeeldingen toe."
  })
);