﻿define(
   ({
    instruction: "Créez le contenu qui apparaît dans ce widget.",
    defaultContent: "Ajoutez du texte, des liens et de petits graphiques ici."
  })
);