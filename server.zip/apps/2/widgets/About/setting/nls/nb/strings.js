﻿define(
   ({
    instruction: "Opprett innholdet som skal vises i dette miniprogrammet.",
    defaultContent: "Legg til tekst, koblinger og små grafikkelementer her."
  })
);