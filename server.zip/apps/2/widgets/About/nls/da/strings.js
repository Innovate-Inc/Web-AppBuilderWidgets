﻿define(
   ({
    _widgetLabel: "Om"
  })
);