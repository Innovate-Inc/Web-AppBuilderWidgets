﻿define(
   ({
    _widgetLabel: "Info zu"
  })
);