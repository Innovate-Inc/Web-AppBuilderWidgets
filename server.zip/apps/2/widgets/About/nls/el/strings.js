﻿define(
   ({
    _widgetLabel: "Πληροφορίες"
  })
);