﻿define(
   ({
    _widgetLabel: "Informazioni"
  })
);