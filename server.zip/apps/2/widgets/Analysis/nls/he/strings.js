﻿define(
   ({
    _widgetLabel: "ניתוח",
    executeAnalysisTip: "לחץ על כלי ניתוח כדי לבצע",
    noToolTip: "לא נבחר כלי ניתוח!",
    back: "הקודם",
    next: "הבא",
    home: "דף הבית",
    jobSubmitted: "נשלח.",
    jobCancelled: "בוטל.",
    jobFailed: "נכשל",
    jobSuccess: "בוצע בהצלחה.",
    executing: "מבצע",
    cancelJob: "בטל את משימת הניתוח",
    paramName: "שם הפרמטר",
    link: "קישור",
    learnMore: "קבל מידע נוסף",
    messages: "הודעות",
    outputs: "פלט",
    outputtip: "הערה: פלט המתקבל מישויות וטבלאות נוסף למפה כשכבות תפעוליות.",
    outputSaveInPortal: "הנתונים נשמרו בפורטל שלך.",
    privilegeError: "עליך להיות מוגדר כמפרסם או כמנהל כדי שתוכל לבצע ניתוח."
  })
);
