﻿define(
   ({
    group: "Tên",
    openAll: "Mở Tất cả trong Bảng điều khiển",
    dropDown: "Hiển thị trong Menu Xổ xuống",
    noGroup: "Không có nhóm tiện ích nào được thiết lập.",
    groupSetLabel: "Thiết lập thuộc tính nhóm tiện ích"
  })
);