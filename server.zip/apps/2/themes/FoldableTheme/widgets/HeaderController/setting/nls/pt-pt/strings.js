﻿define(
   ({
    group: "Nome",
    openAll: "Abrir Todos no Painel",
    dropDown: "Exibir Menu",
    noGroup: "Não está definido qualquer grupo de widgets.",
    groupSetLabel: "Definir as propriedades de grupos de widgets"
  })
);