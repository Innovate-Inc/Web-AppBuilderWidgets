﻿define(
   ({
    group: "ชื่อ",
    openAll: "เปิดทั้งหมดในแผงหน้าปัด",
    dropDown: "แสดงในรายการแบบเลื่อนลง",
    noGroup: "ไม่มีการตั้งกลุ่ม widget",
    groupSetLabel: "การตั้งคุณสมบัติกลุ่ม widget"
  })
);