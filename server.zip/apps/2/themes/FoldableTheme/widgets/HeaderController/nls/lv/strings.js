﻿define(
   ({
    _widgetLabel: "Galvenes kontrolieris",
    signin: "Pierakstīties",
    signout: "Izrakstīties",
    about: "Par",
    signInTo: "Pierakstīties",
    cantSignOutTip: "Šī funkcija nav pieejama priekšskatījuma režīmā."
  })
);
