﻿define(
   ({
    _widgetLabel: "Controller van koptekst",
    signin: "Aanmelden",
    signout: "Afmelden",
    about: "Over",
    signInTo: "Meld u aan bij",
    cantSignOutTip: "Deze functie is niet beschikbaar in de voorbeeldmodus."
  })
);
